var firebaseConfig = {
  apiKey: "AIzaSyCb6zm7_8kdStXjZMgLZpwjGDuTUg0e_qM",
  authDomain: "flutter-prime-df1c5.firebaseapp.com",
  projectId: "flutter-prime-df1c5",
  storageBucket: "flutter-prime-df1c5.appspot.com",
  messagingSenderId: "274514992002",
  appId: "1:274514992002:web:4d77660766f4797500cd9b",
  measurementId: "G-KFPM07RXRC",
  serverKey:
    "AAAA14oqxFc:APA91bE9uJdrjU_FX3gg_EtCfApRqoNojV71m6J-9yCQC7GoL2pBFcN9pdJjLLQxEAUcNxxatfWKLcnl5qCuLsmpPdr_3QRtH9XzfIu1MrLUJU3dHkBc4CGIkYMM9EWgXCNFjudhhQmH",
};
